fun main() {
    var word : String? = null
    val wordLength = word?.length?:10
    print("Jumlah kata dari string SMK Telkom sebanyak $wordLength")
}