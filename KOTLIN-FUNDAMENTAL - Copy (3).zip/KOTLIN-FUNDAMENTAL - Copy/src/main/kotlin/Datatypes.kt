fun main() {
    val firstWord = "SMK"
    val middleWord = "Telkom"
    val lastWord = "Purwokerto"
    println(firstWord + " " + middleWord + " " + lastWord)

    val Panjang: Int  = 10
    val Lebar: Int = 7
    val Luas = Panjang * Lebar
    println("luas pesergi panjang adalah " + Luas)


}
