fun main() {
    val name = "Rakyan"

    print("Hello my name is ")
         println(name)
         print(if (true) "Hobi saya berenang" else "hobi saya renang")
}

