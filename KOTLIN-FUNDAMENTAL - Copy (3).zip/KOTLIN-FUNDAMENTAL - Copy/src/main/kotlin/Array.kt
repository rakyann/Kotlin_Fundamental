fun main(args: Array<String>) {
     val sekolahKU = arrayOf("SMK Telkom Purwokerto didirikan pada tanggal 30 Januari 1993", "That's true Bro")

    println(sekolahKU[0])
    println(sekolahKU.get(1))
}


