fun main(args : Array<String>){

    val KKM:Int = 75
    val nilaikamu: Int = 65
    if(nilaikamu > KKM) {
        println("Nilai kamu $nilaikamu selamat ya!")
    }else{
        println("nilai kamu $nilaikamu , silahkan ikut remidi")
    }
}












