fun main() {
    val line = """
Kotlin is Modern
Kotlin is Consice
Kotlin is Pragmatic
Kotlin is Safe
 """.trimIndent()

    print(line)
}